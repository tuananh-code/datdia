$("#page").on("input", function (event) {
  var input = $(this);
  var sanitizedValue = input.val().replace(/\D/g, "");
  input.val(sanitizedValue);
});

$("#remove").click(function () {
  $("p, br, .getContent").remove();
});

$("#select").change(function () {
  var webOption = $(this).find(".getWeb:Selected");
  var dataWeb = webOption.val();
  var webSelect = $(this).attr("data-web", dataWeb);
});

// Example usage:
$(document).on("click", "#getValue", function (e) {
  e.preventDefault();
  var data = $("#formValue").serializeArray();
  //TODO: uncomment for muaban
  //   var url = $("#select").attr("data-web");
  var url = $("#url").val();
  var page = parseFloat($("#page").val());
  var xPath = $("#xPath").val();
  var pageOption = $("#pageOption").val();
  var moreInfo = $("#moreInfo").val();
  var price = $("#price").val();
  var location = $("#location").val();
  var detail = $("#detail").val();

  // for (var i = 1; i <= page; i++) {
  //     if (pageOption.length === 0) {
  //         var pageNumber = i;
  //     } else {
  //         var pageNumber = pageOption + i;
  //     }
  //     var lengthLocated = located.length;
  //     // var all = [];
  //     // for (var i = 0; i < lengthLocated; i++) {
  //     //   all.push(url + located[i]);
  //     // }
  //     // $.ajax({
  //     //   data: {
  //     //     url: all,
  //     //   },
  //     //   url: "add_link.php",
  //     //   method: "post",
  //     //   success: function (response) {
  //     //     console.log(response);
  //     //   },
  //     // });
  //     // return;
  //     for (var l = 0; l < 1; l++) {
  $.ajax({
    data: {
      url: url,
      // url: url + pageNumber + located[l],
      // page: i,
      xPath: xPath,
    },
    url: "poe.php",
    type: "post",
    // dataType: 'JSON', // It bug the code and don't send value to ajax
    // contentType: false,
    beforeSend: function (xhr) {
      $("#loadingAlert").fadeIn();
    },
    success: function (response) {
      // console.log(response[0]);
      console.log(response);
      // return
      if (response[0]) {
        var result = response[0];
      } else {
        var result = response;
      }
      console.log(result);
      return;
      var contentLength = result["href"].length;
      var href = result["href"];
      if (href.includes("muaban")) {
        var infoName = result["name"];
        var infoAddress = result["price"];
        var infoBed = result["location"];
        var infoBath = result["info"];
      } else if (href.includes("21century")) {
        var infoName = result["name"];
        var infoAddress = result["address"];
        var infoBed = result["bed"];
        var infoBath = result["bath"];
      }
      // console.log(href.length);
      for (var i = 0; i < href.length; i++) {
        $.ajax({
          data: {
            infoName: infoName[i],
            infoAddress: infoAddress[i],
            infoBed: infoBed[i],
            infoBath: infoBath[i],
            // infoDescription: result['description'][i],
            // infoPrivate: result['info_private'][i],
            // infoPublic: result['info_public'][i],
            href: href[i],
          },
          url: "getInfo.php",
          type: "post",
          success: function (getInfo) {
            // var geoLocation = [];
            console.log(getInfo);
            var geoLocation = getInfo["location"];
            $.ajax({
              data: {
                location: geoLocation,
              },
              url: "lat_long_convert.php",
              type: "post",
              success: function (getLatLong) {
                console.log(getLatLong);
              },
            });
          },
        });
      }
    },
    complete: function () {
      $("#loadingAlert").fadeOut();
    },
  });
  // }
  // }
});

$("#update").click(function (e) {
  e.preventDefault();
  $.ajax({
    data: "update",
    url: "update_map.php",
    type: "post",
    success: function (result) {
      console.log(result);
    },
  });
});
